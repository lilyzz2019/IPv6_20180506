#include<reg52.h>
#include<intrins.h>
#include"led.h"
#include"buzz.h"
#include"key.h"
#include"uart.h"
#include"delay.h"
#include"FPM10A.h"
#include"lcd_12864.h"
sbit led1=P1^1;sbit led2=P1^2;

void main()
{	
  Uart_Init();
	Buzz_Init();
	Device_Check();
	Delay_Ms(500); //��ʱ500MS���ȴ�ָ��ģ�鸴λ
	Buzz_Times(1);
	while(1)
	{
							
					FPM10A_Find_Fingerprint();	 
					 
					 Delay_Ms(200);
					 led1=1;led2=1;
	}
}
